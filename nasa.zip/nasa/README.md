# How to locally run the application

1. Open the folder with your text editor (Vscode) (Mkae sure your in same directory as src and public)
2. Open the terminal and run "npm install" to install dependencies 
3. Once finished, run "npm start" and go to localhost:3000

