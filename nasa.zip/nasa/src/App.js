import './App.css';
import Navbar from './Navbar';
import {Typography, Button, TextField} from '@material-ui/core';

//let searchButton = document.querySelector("#search")
// apiKey = "qSiXPbQtaRCYiDC4IIBr22KYp8jjAaoXqHJV1PDN"
//Add event listener to make sure its working
// searchButton.addEventListener("click", ()=> {
//   console.log("button click")
//   sendAPIRequest()
// })


// // async function to retrieve data and interpolate inputs into API URL
async function sendAPIRequest (){
  const lat = document.getElementById("latID").value;
  const lon = document.getElementById("longID").value;
  const datePick = document.getElementById("date").value;
 
let API_KEY = "qSiXPbQtaRCYiDC4IIBr22KYp8jjAaoXqHJV1PDN"
let res = await fetch(`https://api.nasa.gov/planetary/earth/assets?lon=${lon}&lat=${lat}&date=${datePick}&&dim=0.10&api_key=${API_KEY}`);
console.log(res);
let data = await res.json();
console.log(data);
displayData(data);
}

//Function to display the image received
function displayData(data){
document.querySelector('#content').innerHTML = `<img src="${data.url}" width="500px" height="500px">`;

}


function App() {
  return (
    <div className="App">
     <Navbar />
      <br />
    
      <Typography variant="h5">Enter a lattitude and longitude for a satellite image</Typography>
      <hr />
      <Typography variant="h5">Lattitude</Typography> 
      <input id="latID" className="input" size="large" type="number" width="100px" placeholder="Enter Lattitude"  />
      <Typography variant="h5">Longitude</Typography>
      <input id="longID" className="input" type="number" width="100px" placeholder="Enter Longitude"  />
      <br /> <br />
      
      <form className="datePicker" noValidate>
      <TextField
        id="date"
        label="Date (optional)"
        type="date"
        defaultValue="2018-01-01"
        InputLabelProps={{
          shrink: true,
        }}
      />
    </form>

      <br /><br />
      
      <Button onClick={sendAPIRequest} id="search" size="large" width="100px" variant="outlined" color="primary">
        Find Image
      </Button>
      <hr /><br />
      <Typography variant="h5">Result:</Typography> 
      <i> (takes a couple seconds)</i>
      <div id="content">
        <div id="date">

        </div>
      </div>
      <br />

    </div>
  );
}

export default App;
