import React from 'react'
import {AppBar, Typography} from '@material-ui/core';

const Navbar = () => {
    return (
        <div>
            <AppBar  position="static">
        
                <Typography variant="h2" >
                Nasa Pictures
                </Typography>
               

            </AppBar>
        </div>
    )
}

export default Navbar
